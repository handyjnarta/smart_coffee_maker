#ifndef QOREXLIBRARY_H
#define QOREXLIBRARY_H

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "Free_Fonts.h" 
#include <Adafruit_BME280.h>   
#include <ICM20948.h>
#include <FT6336U.h>
#include <PNGdec.h>
#include <driver/i2s.h>
#include <math.h>
#include <vector>
#include "cat.h"
#include "crow.h"
#include "tiger.h"
#include "sheep.h"
#include "rooster.h"
#include "frog.h"
#include "duck.h"
#include "dog.h"
#include "elephant.h"
#include "horse.h"

extern TFT_eSPI tft;
extern Adafruit_BME280 bme;
extern ICM20948 IMU;
extern FT6336U ft6336u;
extern uint16_t x, y, touched;
extern int touchCounter;
extern float prevPressure;
extern float ROLL, PITCH;
extern  unsigned char cat[];
extern  unsigned char crow[];
extern  unsigned char tiger[];
extern  unsigned char sheep[];
extern  unsigned char rooster[];
extern  unsigned char frog[];
extern  unsigned char duck[];   
extern  unsigned char dog[];
extern  unsigned char elephant[];
extern  unsigned char horse[];
extern const i2s_port_t i2s_num;
extern const unsigned char* TheData;
extern uint32_t DataIdx;
extern const esp_err_t result;  // Declaration of result

 
extern float offsetX;
extern float offsetY;
extern float offsetZ;

#define THRESHOLD 1.0  // Ambang batas perubahan heading dalam derajat
#define FILTER_SIZE 10  // Ukuran filter rata-rata bergerak


#define I2S_PORT I2S_NUM_0
//======================================================================================
//---------------------------------Display----------------------------------------------
//======================================================================================
void initDisplay(int rotation, uint16_t fillColor);
void fillScreen( uint16_t color);
void displayMessage(const char* message, int size, int x, int y, uint16_t color);
void displayMessageBold(const char* text, int size, int x, int y, uint32_t color);
void displayMessageItalic(const char* text, int size, int x, int y, uint32_t color);
void setFontStyle(int font);
void decimalNumber(float sensor, int size, int x, int y, uint16_t color);
void displayNumber(float num, int size, int x, int y, uint16_t color);
void drawRectangle(int x, int y, int width, int height, float angle, uint16_t color);  
void fillEllipse(int16_t x, int16_t y, int32_t rx, int32_t ry, uint16_t color);
void fillCircle(int x, int y, int radius, uint16_t color);
void drawCircle(int x, int y, int radius, uint16_t color);
void drawRightTriangle(int x, int y, int base, int height, float angle, uint16_t color);
void drawEquilateralTriangle(int x, int y, int sideLength, float angle, uint16_t color);
void drawIsoscelesTriangle(int x, int y, int base, int height, float angle, uint16_t color);
void drawEllipse(int16_t x, int16_t y, int32_t radiusx, int32_t radiusy, uint16_t color);
void drawButton(const char* text, int textSize, int x, int y, uint16_t btcolor, uint16_t textColor, uint16_t bgColor);
void fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, float angle, uint32_t color);
void drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color);
void fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color);
void displayImage(uint8_t *imageData, uint32_t imageSize, int16_t xpos, int16_t ypos);
void pngDraw(PNGDRAW *pDraw);
void startStopwatch();
void stopStopwatch();
void resetStopwatch();
void updateStopwatch();
void displayStopwatchTime();
bool isStopwatchRunning();
void pauseStopwatch();
void loadingAnimation();
//======================================================================================
//--------------------------------End Display-------------------------------------------
//======================================================================================

//======================================================================================
//-----------------------------------Touch----------------------------------------------
//======================================================================================
void initializeTouch();
void readTouch();
bool areaTouch(int x1, int x2, int y1, int y2);
void detectSwipeLeftRight();
void detectSwipeUpDown();
void draw();
void draw2();
//======================================================================================
//---------------------------------End Touch--------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------Sound-------------------------------------------
//======================================================================================
struct WavHeader_Struct
{ 
    char RIFFSectionID[4];
    uint32_t Size;
    char RiffFormat[4];
    char FormatSectionID[4];
    uint32_t FormatSize;
    uint16_t FormatID;
    uint16_t NumChannels;
    uint32_t SampleRate;
    uint32_t ByteRate;
    uint16_t BlockAlign;
    uint16_t BitsPerSample;
    char DataSectionID[4];
    uint32_t DataSize;
};

extern WavHeader_Struct WavHeader;

//speaker
static const i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = 44100,                            // Note, this will be changed later
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,       // high interrupt priority
    .dma_buf_count = 8,                             // 8 buffers
    .dma_buf_len = 1024,                            // 1K per buffer, so 8K of buffer space
    .use_apll=0,
    .tx_desc_auto_clear= true,
    .fixed_mclk=-1
};
extern const i2s_config_t i2s_config;

//speaker
static const i2s_pin_config_t pin_config = {
    .bck_io_num = 17,                                 // The bit clock connectiom, goes to pin 27 of ESP32
    .ws_io_num = 16,                                  // Word select, also known as word select or left right clock
    .data_out_num = 26,                               // Data out from the ESP32, connect to DIN on 38357A
    .data_in_num = I2S_PIN_NO_CHANGE                  // we are not interested in I2S data into the ESP32
};
extern const i2s_pin_config_t pin_config;

bool ValidWavData(WavHeader_Struct* Wav);
void DumpWAVHeader(WavHeader_Struct* Wav);
void PrintData(const char* Data, uint8_t NumBytes);
void playSound(const uint8_t* wavData);

void i2sAudioInit();
void playTone(int frequency, int duration);
void setVolume(int newVolume);
void startTone();
void stopTone();
void animalSound(const uint8_t* wavData);
//======================================================================================
//--------------------------------End Sound-------------------------------------------
//======================================================================================

//======================================================================================
//-------------------------------------BME----------------------------------------------
//======================================================================================
void initBME();
float bmeTemperature();
float bmePressure();
float bmeAltitude(float seaLevelPressure);
float bmeHumidity();
void weatherPrediction(float pressure, float prevPressure, float temperature, float humidity, int x, int y);
//======================================================================================
//------------------------------------End BME-------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------------IMU---------------------------------------------
//======================================================================================
void initIMU();
void updateIMU();
float imuAccelX();
float imuAccelY();
float imuAccelZ();
float imuGyroX();
float imuGyroY();
float imuGyroZ();
float imuMagX();
float imuMagY();
float imuMagZ();
float imuTemperature();
void calibrateCompass();
float readCompass();
const char* compasDirection();
void drawCompassNeedle(float goal);
void lineCompass(int x0, int y0, int x1, int y1, uint16_t color);
// void updateCompass();
//======================================================================================
//------------------------------------End IMU-------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------------MIC---------------------------------------------
//======================================================================================
void micSetup();
float readMic();
void readClapOrWhistle();
//======================================================================================
//--------------------------------------End MIC-----------------------------------------
//======================================================================================

#endif
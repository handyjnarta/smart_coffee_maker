// horse_data.h
#ifndef DUCK_H
#define DUCK_H

extern unsigned char duck[];

#endif // DUCK_H

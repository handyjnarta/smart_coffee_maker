// horse_data.h
#ifndef CAT_H
#define CAT_H

extern unsigned char cat[];

#endif // CAT_H

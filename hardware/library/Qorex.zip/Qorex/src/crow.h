// horse_data.h
#ifndef CROW_H
#define CROW_H

extern unsigned char crow[];

#endif // CROW_H

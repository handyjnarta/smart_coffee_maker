// horse_data.h
#ifndef ROOSTER_H
#define ROOSTER_H

extern unsigned char rooster[];

#endif // ROOSTER_H

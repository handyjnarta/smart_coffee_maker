// horse_data.h
#ifndef HORSE_H
#define HORSE_H

extern unsigned char horse[];

#endif // HORSE_DATA_H

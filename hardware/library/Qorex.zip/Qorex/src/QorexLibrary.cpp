#include "QorexLibrary.h"
#include "Free_Fonts.h" 
#include <cstring>


#define MAX_IMAGE_WIDTH 240
#define SAMPLE_RATE 16000
#define FFT_SAMPLES 2048 

#define I2S_WS 32
#define I2S_SD 33
#define I2S_SCK I2S_PIN_NO_CHANGE
#define I2S_PORT I2S_NUM_0

TFT_eSPI tft = TFT_eSPI();
Adafruit_BME280 bme;
PNG png;
#define PI 3.14159265358979323846

ICM20948 IMU(Wire, 0x68);
FT6336U ft6336u(21, 22, 19, 4);

float ROLL, PITCH;
float prevPressure = 0;
int16_t xpos = 0, ypos = 0;
uint16_t x, y, touched;
int16_t startX = 0, startY = 0; // Coordinates of the initial touch
bool swiped = false;
FT6336U_TouchPointType tp;      // Variable to store touch data
const int sampleRate = 44100;    // Sample rate
const i2s_port_t i2s_num = I2S_NUM_0; // i2s port number
// const int i2s_bck_pin = 17;      // Bit Clock (BCK) pin
// const int i2s_ws_pin = 16;       // Word Select (WS) pin, also known as LRCLK
// const int i2s_data_out_pin = 26; // Data Out (DOUT) pin, which connects to DIN on the I2S amplifier
int volume = 100; // Default volume set to 100%
int16_t prevX = -1, prevY = -1; // To store the previous position
#define PEN_SIZE 6  // You can change to reduce the pen size while drawing
unsigned long startTime = 0;
unsigned long elapsedTime = 0;
bool running = false;
char timeString[9];

unsigned const char* TheData;
uint32_t DataIdx=0;

WavHeader_Struct WavHeader;

float heading = 0.0;
float previousHeading = -1.0; // Initialize to a value that is not a valid heading
char direction[3] = "";
char previousDirection[3] = ""; // Initialize to an empty string


#define NUM_SAMPLES 200   // Jumlah sampel yang akan digunakan untuk kalibrasi
#define CALIBRATION_PERIOD_MS 100  // Periode waktu antara setiap sampel (dalam milidetik)

float headingFilter[FILTER_SIZE];
static int filterIndex = 0;
static bool filterFilled = false;
static char newDirection[3];
float filteredHeading = 0.0;

// QorexLibrary qorexLibrary;  // Global instance of QorexLibrary

// double vReal[FFT_SAMPLES];
// double vImag[FFT_SAMPLES];
// int16_t samples[FFT_SAMPLES];
size_t bytes_read;
// ArduinoFFT<double> FFT = ArduinoFFT<double>(vReal, vImag, FFT_SAMPLES, SAMPLE_RATE);

float thresholdClap = 300;
float thresholdWhistle = 1000;
unsigned long clapDuration = 1;  // Durasi minimum untuk mendeteksi tepukan (dalam milidetik)
unsigned long whistleDuration = 500;  // Durasi minimum untuk mendeteksi siulan (dalam milidetik)

size_t bytesIn = 0;
#define bufferLen 128
int16_t sBuffer[bufferLen];
#define thresholdHigh 1000  // Adjust threshold for your environment
#define thresholdLow 200    // Adjust threshold for your environment
#define minWhistleDuration 350  // Minimum duration for a whistle in ms
#define minPeaksForWhistle 8    // Minimum number of peaks for a whistle

std::vector<int16_t> waveData;
std::vector<int16_t> tempWaveBuffer;
int32_t i2s_read_buffer[bufferLen];

extern bool collectingWave;
unsigned long playTime = 0;
unsigned long endTime = 0;
unsigned long lastBelowThresholdTime = 0;
const unsigned long thresholdDelay = 100; // 100 ms delay after falling below thresholdLow
const unsigned long debounceDelay = 2000; // 2 seconds debounce delay at the start
extern unsigned long milTime;
const esp_err_t result = ESP_OK;  // Definition and initialization of result
int16_t sample;
// int16_t samples_read;
  float mean = 0;

// Deklarasi variabel global untuk deteksi
extern bool whistleDetected;
extern bool clapDetected;
//======================================================================================
//---------------------------------Display----------------------------------------------
//======================================================================================
void initDisplay(int rotation, uint16_t fillColor) {
  tft.init();
  tft.setRotation(rotation);
  tft.fillScreen(fillColor);
}

void fillScreen( uint16_t color){
  tft.fillScreen(color);
}

void displayMessage(const char* message, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.setCursor(x, y);
  tft.println(message);
}

void displayMessageBold(const char* text, int size, int x, int y, uint32_t color){
  // Set the font to bold
  tft.setFreeFont(FSB9); // Set the bold font (FSSB9)

  tft.setTextSize(size);

  // Set text color 
  tft.setTextColor(color);

  // Set text cursor position
  tft.setCursor(x, y);

  // Print the text
  tft.print(text);

  // Reset font to default (non-bold)
  tft.setFreeFont(0);
}

void displayMessageItalic(const char* text, int size, int x, int y, uint32_t color){
  // Set the font to bold
  tft.setFreeFont(FSI9); // Set the bold font (FSSB9)

  tft.setTextSize(size);

  // Set text color 
  tft.setTextColor(color);

  // Set text cursor position
  tft.setCursor(x, y);

  // Print the text
  tft.print(text);

  // Reset font to default (non-bold)
  tft.setFreeFont(0);
}

void setFontStyle(int font){
  if (font == 1){
     tft.setFreeFont(SL8);
  }
  else if (font == 2){
     tft.setFreeFont(DS10);
  }
  else if (font == 3){
     tft.setFreeFont(RS10);
  }
  else{
      tft.setFreeFont(0);
  }    
}

void decimalNumber(float sensor, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.drawFloat(sensor, 2, x, y);
}

void displayNumber(float num, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.drawFloat(num, 0, x, y);
}

void drawRectangle(int x, int y, int width, int height, float angle, uint16_t color) {
    // Convert angle to radians
    float rad = angle * DEG_TO_RAD;

    // Calculate the half-dimensions of the box
    float halfWidth = width / 2.0;
    float halfHeight = height / 2.0;

    // Calculate the center of the box
    float cx = x + halfWidth;
    float cy = y + halfHeight;

    // Calculate the rotated coordinates of each corner of the box
    float corners[4][2];
    corners[0][0] = -halfWidth;
    corners[0][1] = -halfHeight;
    corners[1][0] = halfWidth;
    corners[1][1] = -halfHeight;
    corners[2][0] = halfWidth;
    corners[2][1] = halfHeight;
    corners[3][0] = -halfWidth;
    corners[3][1] = halfHeight;

    for (int i = 0; i < 4; i++) {
        float xRot = corners[i][0] * cos(rad) - corners[i][1] * sin(rad);
        float yRot = corners[i][0] * sin(rad) + corners[i][1] * cos(rad);
        corners[i][0] = xRot + cx;
        corners[i][1] = yRot + cy;
    }

    // Draw the rotated box by connecting the corners
    tft.drawLine(corners[0][0], corners[0][1], corners[1][0], corners[1][1], color);
    tft.drawLine(corners[1][0], corners[1][1], corners[2][0], corners[2][1], color);
    tft.drawLine(corners[2][0], corners[2][1], corners[3][0], corners[3][1], color);
    tft.drawLine(corners[3][0], corners[3][1], corners[0][0], corners[0][1], color);
}

void fillEllipse(int16_t x, int16_t y, int32_t rx, int32_t ry, uint16_t color){
  tft.fillEllipse(x, y, rx, ry, color);
}

void fillCircle(int x, int y, int radius, uint16_t color){
  tft.fillCircle(x, y, radius, color);
}

void drawCircle(int x, int y, int radius, uint16_t color){
  tft.drawCircle(x, y, radius, color);
}

void drawEllipse(int16_t x, int16_t y, int32_t radiusx, int32_t radiusy, uint16_t color){
  tft.drawEllipse(x, y, radiusx, radiusy, color);
}

void rotatePoint(int &x, int &y, int cx, int cy, float angle) {
    // Convert angle to radians
    float rad = angle * DEG_TO_RAD;

    // Translate point to origin
    int tempX = x - cx;
    int tempY = y - cy;

    // Rotate point
    int rotatedX = tempX * cos(rad) - tempY * sin(rad);
    int rotatedY = tempX * sin(rad) + tempY * cos(rad);

    // Translate point back
    x = rotatedX + cx;
    y = rotatedY + cy;
}

void drawRightTriangle(int x, int y, int base, int height, float angle, uint16_t color) {
    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + base, y1 = y;
    int x2 = x, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawEquilateralTriangle(int x, int y, int sideLength, float angle, uint16_t color) {
    // Calculate the height of the equilateral triangle
    int height = sideLength * sqrt(3) / 2;

    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + sideLength, y1 = y;
    int x2 = x + sideLength / 2, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawIsoscelesTriangle(int x, int y, int base, int height, float angle, uint16_t color) {
    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + base, y1 = y;
    int x2 = x + base / 2, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawButton(const char* text, int textSize, int x, int y, uint16_t btcolor, uint16_t textColor, uint16_t bgColor) {
    // Set the text size
    tft.setTextSize(textSize);
    
    // Estimate the width and height of the text
    int textWidth = strlen(text) * 6 * textSize; // Approximate width: 6 pixels per character
    int textHeight = 8 * textSize; // Approximate height: 8 pixels per character

    // Calculate button dimensions
    int padding = 10;
    int buttonWidth = textWidth + 2 * padding;
    int buttonHeight = textHeight + 2 * padding;

    // Draw the button rectangle
    tft.fillRoundRect(x, y, buttonWidth, buttonHeight, 5, btcolor);
    tft.drawRoundRect(x, y, buttonWidth, buttonHeight, 5, bgColor);

    // Calculate the coordinates to center the text
    int16_t xText = x + (buttonWidth - textWidth) / 2;
    int16_t yText = y + (buttonHeight - textHeight) / 2;

    // Set the text color and draw the text
    tft.setTextColor(textColor, btcolor);
    tft.setCursor(xText, yText);
    tft.print(text);
}

void fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, float angle, uint32_t color) {
  if (angle == 0) {
    // No rotation, draw normally
    tft.fillRect(x, y, w, h, color);
  } else {
    // Rotation needed
    float rad = angle * DEG_TO_RAD; // Convert angle to radians
    float cosA = cos(rad);
    float sinA = sin(rad);

    // Calculate coordinates of the corners
    int x0 = -w / 2;
    int y0 = -h / 2;
    int x1 = w / 2;
    int y1 = -h / 2;
    int x2 = w / 2;
    int y2 = h / 2;
    int x3 = -w / 2;
    int y3 = h / 2;

    // Rotate the corners around the center point (x, y)
    int xr0 = x + x0 * cosA - y0 * sinA;
    int yr0 = y + x0 * sinA + y0 * cosA;
    int xr1 = x + x1 * cosA - y1 * sinA;
    int yr1 = y + x1 * sinA + y1 * cosA;
    int xr2 = x + x2 * cosA - y2 * sinA;
    int yr2 = y + x2 * sinA + y2 * cosA;
    int xr3 = x + x3 * cosA - y3 * sinA;
    int yr3 = y + x3 * sinA + y3 * cosA;

    // Draw filled triangles to create the filled rectangle
    tft.fillTriangle(xr0, yr0, xr1, yr1, xr2, yr2, color);
    tft.fillTriangle(xr0, yr0, xr2, yr2, xr3, yr3, color);
  }
}
void drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color) {
  float rad = angle * DEG_TO_RAD; // Convert angle to radians
  float cosA = cos(rad);
  float sinA = sin(rad);

  int32_t cx = (x0 + x1 + x2) / 3;
  int32_t cy = (y0 + y1 + y2) / 3;

  // Translate points to origin
  int32_t tx0 = x0 - cx;
  int32_t ty0 = y0 - cy;
  int32_t tx1 = x1 - cx;
  int32_t ty1 = y1 - cy;
  int32_t tx2 = x2 - cx;
  int32_t ty2 = y2 - cy;

  // Rotate points
  int32_t rx0 = tx0 * cosA - ty0 * sinA;
  int32_t ry0 = tx0 * sinA + ty0 * cosA;
  int32_t rx1 = tx1 * cosA - ty1 * sinA;
  int32_t ry1 = tx1 * sinA + ty1 * cosA;
  int32_t rx2 = tx2 * cosA - ty2 * sinA;
  int32_t ry2 = tx2 * sinA + ty2 * cosA;

  // Translate points back
  int32_t nx0 = rx0 + cx;
  int32_t ny0 = ry0 + cy;
  int32_t nx1 = rx1 + cx;
  int32_t ny1 = ry1 + cy;
  int32_t nx2 = rx2 + cx;
  int32_t ny2 = ry2 + cy;

  // Draw the rotated triangle
  tft.drawLine(nx0, ny0, nx1, ny1, color);
  tft.drawLine(nx1, ny1, nx2, ny2, color);
  tft.drawLine(nx2, ny2, nx0, ny0, color);
}

void fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color){

  float rad = angle * DEG_TO_RAD; // Convert angle to radians
  float cosA = cos(rad);
  float sinA = sin(rad);

  int32_t cx = (x0 + x1 + x2) / 3;
  int32_t cy = (y0 + y1 + y2) / 3;

  // Translate points to origin
  int32_t tx0 = x0 - cx;
  int32_t ty0 = y0 - cy;
  int32_t tx1 = x1 - cx;
  int32_t ty1 = y1 - cy;
  int32_t tx2 = x2 - cx;
  int32_t ty2 = y2 - cy;

  // Rotate points
  int32_t rx0 = tx0 * cosA - ty0 * sinA;
  int32_t ry0 = tx0 * sinA + ty0 * cosA;
  int32_t rx1 = tx1 * cosA - ty1 * sinA;
  int32_t ry1 = tx1 * sinA + ty1 * cosA;
  int32_t rx2 = tx2 * cosA - ty2 * sinA;
  int32_t ry2 = tx2 * sinA + ty2 * cosA;

  // Translate points back
  int32_t nx0 = rx0 + cx;
  int32_t ny0 = ry0 + cy;
  int32_t nx1 = rx1 + cx;
  int32_t ny1 = ry1 + cy;
  int32_t nx2 = rx2 + cx;
  int32_t ny2 = ry2 + cy;

  // Draw the rotated triangle
  tft.fillTriangle(nx0, ny0, nx1, ny1, nx2, ny2, color);
}

struct ImagePosition {
    int16_t x;
    int16_t y;
} imagePos;

void displayImage(uint8_t *imageData, uint32_t imageSize, int16_t xpos, int16_t ypos) {
    imagePos.x = xpos;
    imagePos.y = ypos;
    
    int16_t rc = png.openFLASH(imageData, imageSize, pngDraw);
    if (rc == PNG_SUCCESS) {
        Serial.println("Successfully opened png file");
        Serial.printf("image specs: (%d x %d), %d bpp, pixel type: %d\n", png.getWidth(), png.getHeight(), png.getBpp(), png.getPixelType());
        tft.startWrite();
        uint32_t dt = millis();
        rc = png.decode(NULL, 0);
        Serial.print(millis() - dt); Serial.println("ms");
        tft.endWrite();
        // png.close(); // not needed for memory->memory decode
    }
}

void pngDraw(PNGDRAW *pDraw) {
    uint16_t lineBuffer[MAX_IMAGE_WIDTH];
    png.getLineAsRGB565(pDraw, lineBuffer, PNG_RGB565_BIG_ENDIAN, 0xffffffff);
    tft.pushImage(imagePos.x, imagePos.y + pDraw->y, pDraw->iWidth, 1, lineBuffer);
}

void startStopwatch() {
    if (!running) {
        running = true;
        startTime = millis() - elapsedTime;
    }
}

void stopStopwatch() {
    if (running) {
        running = false;
        elapsedTime = millis() - startTime;
    }
}

void resetStopwatch() {
    startTime = 0;
    elapsedTime = 0;
    running = false;
    displayStopwatchTime();
}

void updateStopwatch() {
    if (running) {
        elapsedTime = millis() - startTime;
        displayStopwatchTime();
    }
}

void displayStopwatchTime() {
    int seconds = (elapsedTime / 1000) % 60;
    int minutes = (elapsedTime / (1000 * 60)) % 60;
    int hours = (elapsedTime / (1000 * 60 * 60)) % 24;
    sprintf(timeString, "%02d:%02d:%02d", hours, minutes, seconds);
    tft.fillRect(18, 78, 202, 65, TFT_YELLOW); // Drawing stopwatch area with light yellow color
    displayMessage(timeString, 3, 50, 100, TFT_BLACK);
}

bool isStopwatchRunning() {
    return running;
}

  void drawLoading() {
    int x0 = 300;
    int y0 = 60;
    int x1 = 280;
    int y1 = 60;

    for (int i = 0; i < 14; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      x0 = x1;
      x1 = x0 - 20;
      delay(100);
    }
  }

  void drawLoading1() {
    drawLoading();
    int x0 = 20;
    int y0 = 60;
    int x1 = 20;
    int y1 = 80;

    for (int i = 0; i < 9; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      y0 = y1;
      y1 = y0 + 10;
      delay(100);
    }
  }

  void drawLoading2() {
    drawLoading1();
    int x0 = 20;
    int y0 = 160;
    int x1 = 40;
    int y1 = 160;

    for (int i = 0; i < 14; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      x0 = x1;
      x1 = x0 + 20;
      delay(100);
    }
  }

  void drawLoading3() {
    drawLoading2();
    int x0 = 300;
    int y0 = 160;
    int x1 = 300;
    int y1 = 150;

    for (int i = 0; i < 10; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      y0 = y1;
      y1 = y0 - 10;
      delay(100);
    }
  }
  
  void loadingAnimation(){
    drawLoading3();
  }

//======================================================================================
//--------------------------------End Display-------------------------------------------
//======================================================================================

//======================================================================================
//-----------------------------------Touch----------------------------------------------
//======================================================================================

void initializeTouch() {
    ft6336u.begin();
}

void readTouch() {
    x = ft6336u.read_touch1_x();              // Read the x-coordinate of the first touch point
    y = ft6336u.read_touch1_y();              // Read the y-coordinate of the first touch point
    touched = ft6336u.read_td_status();       // Read touch status
    tp = ft6336u.scan(); // Scan for touch input
}

bool areaTouch(int x1, int x2, int y1, int y2) {
    return (x > x1 && x < x2 && y > y1 && y < y2);
}

void detectSwipeLeftRight() {
    if (tp.touch_count == 1) { // If one touch is detected
        int16_t y = tp.tp[0].y;  // Get the Y coordinate

        if (!swiped) {
            if (startY == 0) { // If this is the first touch
                startY = y;
            }
            int16_t deltaY = y - startY; // Calculate the change in Y
            if (abs(deltaY) > 30) { // Detect swipe if the change is significant
                // Increment or decrement counter and wrap around using modulo 2
                touchCounter = (touchCounter + (deltaY > 0 ? 1 : -1) + 2) % 2; 
                swiped = true; // Mark swipe as detected
                startY = 0; // Reset startY for next swipe detection
            }
        }
    } else { // Reset coordinate if no touch is detected
        startY = 0;
        swiped = false;
    }
}

void detectSwipeUpDown(){
    if (tp.touch_count == 1) { // If one touch is detected    
    int16_t x = tp.tp[0].x;  // Get the Y coordinate

    if (!swiped) {
      if (startX == 0) { // If this is the first touch
        startX = x;
      }
      int16_t deltaX = x - startX; // Calculate the change in Y
      if (abs(deltaX) > 30) { // Detect swipe
        touchCounter = (touchCounter + (deltaX > 0 ? 1 : -1) + 2) % 2; // Increment or decrement counter
        swiped = true;
        startX = 0;
      }
    }
  } else { // Reset coordinate if no touch is detected
    startX = 0;
    swiped = false;
  }
}

  void plotLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color) 
  {
    // Calculate differences and signs for incremental steps
    int16_t dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int16_t dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int16_t err = dx + dy, e2; /* error value e_xy */

    // Loop through all points between the start and end coordinates
    while (true) 
    {
      // Draw a point at the current coordinates
      tft.fillCircle(x0, y0, PEN_SIZE, color); 

      // Check if the end point is reached
      if (x0 == x1 && y0 == y1) break;

      // Calculate error values for next point
      e2 = 2 * err;

      // Adjust x coordinate and error value if needed
      if (e2 >= dy) { err += dy; x0 += sx; }

      // Adjust y coordinate and error value if needed
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }

void draw() {
  tp = ft6336u.scan(); 
  if (tp.tp[0].status == 1) {
    int16_t x = tp.tp[0].x;
    int16_t y = tp.tp[0].y;
    switch (tft.getRotation()) {
      case 2:
        break;
      case 1: {
        int16_t temp = x;
        x =  tft.width() - y;
        y = temp;
        break;
      }
      case 0: {
        x = tft.width() - x;
        y = tft.height() - y;
        break;
      }
      case 3: {
        int16_t temp = x;
        x = y;
        y = tft.height() - temp;
        break;
      }
    }
    if (prevX != -1 && prevY != -1) {
      plotLine(prevX, prevY, x, y, TFT_RED);
    }
    prevX = x;
    prevY = y;
  } else {
    prevX = -1;
    prevY = -1;
  }
}

// void draw2(){ 
//     tp = ft6336u.scan();  // Scan for touch input
//   if (tp.tp[0].status == 1) {  // Check if there is a touch input
//     int16_t x = tp.tp[0].x, y = tp.tp[0].y;  // Get the touch coordinates
//     switch (tft.getRotation()) {  // Adjust coordinates based on screen rotation
//       case 0:
//         break;  // No adjustment needed for rotation 0
//       case 1:
//         std::swap(x, y); y = tft.height() - y; break;  // Swap x and y, and adjust y
//       case 2:
//         x = tft.width() - x; y = tft.height() - y; break;  // Adjust x and y
//       case 3:
//         std::swap(x, y); x = tft.width() - x; break;  // Swap x and y, and adjust x
//     }
//     if (prevX != -1 && prevY != -1) plotLine(prevX, prevY, x, y, TFT_RED);  // Draw a line from the previous point to the current point
//     prevX = x; prevY = y;  // Update the previous point to the current point
//   } else {
//     prevX = -1; prevY = -1;  // Reset the previous point if there is no touch input
//   }
// }

//======================================================================================
//---------------------------------End Touch--------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------Sound-----------------------------------------------
//======================================================================================
void i2sAudioInit(){
const i2s_config_t i2s_config ={
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = 44100,                            // Note, this will be changed later
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,       // high interrupt priority
    .dma_buf_count = 8,                             // 8 buffers
    .dma_buf_len = 1024,                            // 1K per buffer, so 8K of buffer space
    .use_apll=0,
    .tx_desc_auto_clear= true,
    .fixed_mclk=-1
};

const i2s_pin_config_t pin_config ={
    .bck_io_num = 17,                                 // The bit clock connectiom, goes to pin 27 of ESP32
    .ws_io_num = 16,                                  // Word select, also known as word select or left right clock
    .data_out_num = 26,                               // Data out from the ESP32, connect to DIN on 38357A
    .data_in_num = I2S_PIN_NO_CHANGE                  // we are not interested in I2S data into the ESP32
};

i2s_driver_install(i2s_num, &i2s_config, 0, NULL);
i2s_set_pin(i2s_num, &pin_config);
i2s_set_clk(i2s_num, sampleRate, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO);

}

void setVolume(int newVolume) {
  volume = newVolume;
  if (volume < 0) volume = 0;
  if (volume > 100) volume = 100;
}

void playTone(int frequency, int duration) {
  const int maxAmplitude = 10000; // Maximum amplitude of the waveform
  const int amplitude = (maxAmplitude * volume) / 100; // Adjust amplitude according to volume
  const int samples = sampleRate / frequency;
  int16_t sample;
  size_t bytes_written;
  int cycles = (duration * sampleRate) / 1000 / samples;

  for (int j = 0; j < cycles; j++) {
    for (int i = 0; i < samples; i++) {
      sample = (int16_t)(amplitude * sinf(2.0f * PI * i / samples));
      i2s_write(i2s_num, &sample, sizeof(sample), &bytes_written, portMAX_DELAY);
    }
  }
}

void playSound(const uint8_t* wavData) {
  WavHeader_Struct WavHeader;
  memcpy(&WavHeader, wavData, 44);  // Copy the header part of the wav data into our structure

  if (ValidWavData(&WavHeader)) {
    // Configure I2S
    i2s_driver_install(i2s_num, &i2s_config, 0, NULL);  // ESP32 will allocate resources to run I2S
    i2s_set_pin(i2s_num, &pin_config);                  // Set the I2S pins
    i2s_set_sample_rates(i2s_num, WavHeader.SampleRate);  // Set sample rate

    // Start playing WAV data
    const uint8_t* dataPtr = wavData + 44;  // Pointer to start of audio data
    size_t dataSize = WavHeader.DataSize;
    size_t dataIdx = 0;
    size_t bytesWritten;

    while (dataIdx < dataSize) {
      i2s_write(i2s_num, dataPtr + dataIdx, 4, &bytesWritten, portMAX_DELAY);
      dataIdx += 4;
    }
  } else {
    Serial.println("Invalid WAV data");
  }
}

bool ValidWavData(WavHeader_Struct* Wav)
{
  
  if(memcmp(Wav->RIFFSectionID,"RIFF",4)!=0) 
  {    
    Serial.print("Invlaid data - Not RIFF format");
    return false;        
  }
  if(memcmp(Wav->RiffFormat,"WAVE",4)!=0)
  {
    Serial.print("Invlaid data - Not Wave file");
    return false;           
  }
  if(memcmp(Wav->FormatSectionID,"fmt",3)!=0) 
  {
    Serial.print("Invlaid data - No format section found");
    return false;       
  }
  if(memcmp(Wav->DataSectionID,"data",4)!=0) 
  {
    Serial.print("Invlaid data - data section not found");
    return false;      
  }
  if(Wav->FormatID!=1) 
  {
    Serial.print("Invlaid data - format Id must be 1");
    return false;                          
  }
  if(Wav->FormatSize!=16) 
  {
    Serial.print("Invlaid data - format section size must be 16.");
    return false;                          
  }
  if((Wav->NumChannels!=1)&(Wav->NumChannels!=2))
  {
    Serial.print("Invlaid data - only mono or stereo permitted.");
    return false;   
  }
  if(Wav->SampleRate>48000) 
  {
    Serial.print("Invlaid data - Sample rate cannot be greater than 48000");
    return false;                       
  }
  if((Wav->BitsPerSample!=8)& (Wav->BitsPerSample!=16)) 
  {
    Serial.print("Invlaid data - Only 8 or 16 bits per sample permitted.");
    return false;                        
  }
  return true;
  // return header->ChunkID == 0x52494646 && header->Format == 0x57415645;  
}

void DumpWAVHeader(WavHeader_Struct* Wav)
{
  if(memcmp(Wav->RIFFSectionID,"RIFF",4)!=0)
  {
    Serial.print("Not a RIFF format file - ");    
    PrintData(Wav->RIFFSectionID,4);
    return;
  } 
  if(memcmp(Wav->RiffFormat,"WAVE",4)!=0)
  {
    Serial.print("Not a WAVE file - ");  
    PrintData(Wav->RiffFormat,4);  
    return;
  }  
  if(memcmp(Wav->FormatSectionID,"fmt",3)!=0)
  {
    Serial.print("fmt ID not present - ");
    PrintData(Wav->FormatSectionID,3);      
    return;
  } 
  if(memcmp(Wav->DataSectionID,"data",4)!=0)
  {
    Serial.print("data ID not present - "); 
    PrintData(Wav->DataSectionID,4);
    return;
  }  
  // All looks good, dump the data
  Serial.print("Total size :");Serial.println(Wav->Size);
  Serial.print("Format section size :");Serial.println(Wav->FormatSize);
  Serial.print("Wave format :");Serial.println(Wav->FormatID);
  Serial.print("Channels :");Serial.println(Wav->NumChannels);
  Serial.print("Sample Rate :");Serial.println(Wav->SampleRate);
  Serial.print("Byte Rate :");Serial.println(Wav->ByteRate);
  Serial.print("Block Align :");Serial.println(Wav->BlockAlign);
  Serial.print("Bits Per Sample :");Serial.println(Wav->BitsPerSample);
  Serial.print("Data Size :");Serial.println(Wav->DataSize);
}

void PrintData(const char* Data,uint8_t NumBytes)
{
    for(uint8_t i=0;i<NumBytes;i++)
      Serial.print(Data[i]); 
      Serial.println();  
}

void startTone() {
  // Hentikan nada dengan menghentikan I2S
  i2s_start(i2s_num);
}

void stopTone() {
  // Hentikan nada dengan menghentikan I2S
  i2s_stop(i2s_num);
}
void animalSound(const uint8_t* wavData){
    playSound(wavData);         
}

//======================================================================================
//--------------------------------End Sound-------------------------------------------
//======================================================================================

//======================================================================================
//-------------------------------------BME----------------------------------------------
//======================================================================================
void initBME() {
  int statusBme = bme.begin(0x76); 
  if (!statusBme) {
    Serial.println("Could not find a valid BME 280 sensor, check wiring!");
    while (1);
  }
}

float bmeTemperature() {
  return bme.readTemperature();
}

float bmePressure() {
  return bme.readPressure();
}

float bmeAltitude(float seaLevelPressure) {
  return bme.readAltitude(seaLevelPressure);
}

float bmeHumidity(){
  return bme.readHumidity();
}

void weatherPrediction(float pressure, float prevPressure, float temperature, float humidity, int x, int y) {
    tft.fillRect(x, y, 240, 50, TFT_BLACK);  // Clear the previous prediction
    tft.setCursor(x, y);

    String prediction = "Weather: ";
    
    // Basic pressure trend prediction
    if (pressure > prevPressure + 0.1) {
        prediction += "Better";
        tft.setTextColor(TFT_GREEN);
    } else if (pressure < prevPressure - 0.1) {
        prediction += "Worse";
        tft.setTextColor(TFT_RED);
    } else {
        prediction += "Stable";
        tft.setTextColor(TFT_WHITE);
    }

    tft.println(prediction);

    // Additional hints based on temperature and humidity
    tft.setCursor(0, 170);
    if (humidity > 80) {
        tft.println("High Humidity: Possible rain");
    } else if (temperature > 30) {
        tft.println("High Temp: Hot weather");
    } else if (temperature < 0) {
        tft.println("Low Temp: Cold weather");
    } else {
        tft.println("Temp and Humidity Normal");
    }
}
//======================================================================================
//------------------------------------End BME-------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------------IMU---------------------------------------------
//======================================================================================
void initIMU(){
  while(!Serial) {}

  // start communication with IMU 
  int statusImu;
  statusImu = IMU.begin();
  Serial.print("status = ");
  Serial.println(statusImu);
  if (statusImu < 0) {
    Serial.println("IMU initialization unsuccessful");
    Serial.println("Check IMU wiring or try cycling power");
    Serial.print("Status: ");
    Serial.println(statusImu);
    while(1) {}
  }
}

void updateIMU(){
  IMU.readSensor();

}

float imuAccelX() {
  return IMU.getAccelX_mss();
}

float imuAccelY() {
  return IMU.getAccelY_mss();
}

float imuAccelZ() {
  return IMU.getAccelZ_mss();
}

float imuGyroX() {
  return IMU.getGyroX_rads();
}

float imuGyroY() {
  return IMU.getGyroY_rads();
}

float imuGyroZ() {
  return IMU.getGyroZ_rads();
}

float imuMagX() {
  return IMU.getMagX_uT();
}

float imuMagY() {
  return IMU.getMagY_uT();
}

float imuMagZ() {
  return IMU.getMagZ_uT();
}

float imuTemperature() {
  return IMU.getTemperature_C();
}

void calibrateCompass(){
  float sumX = 0.0, sumY = 0.0, sumZ = 0.0;
  for (int i = 0; i < NUM_SAMPLES; i++) {
    IMU.readSensor(); // Baca sensor
    sumX += IMU.getMagX_uT();
    sumY += IMU.getMagY_uT();
    sumZ += IMU.getMagZ_uT();
    delay(CALIBRATION_PERIOD_MS);  // Tunggu sebelum mengambil sampel berikutnya
  }
  offsetX = sumX / NUM_SAMPLES;
  offsetY = sumY / NUM_SAMPLES;
  offsetZ = sumZ / NUM_SAMPLES;  
}

float readCompass(){
 // Get magnetometer values
  float magX = IMU.getMagX_uT() - offsetX;
  float magY = IMU.getMagY_uT() - offsetY;

  // Calculate heading
  float newHeading = atan2(-magY, magX) * 180.0 / PI + 180.0; // Menambahkan 180 derajat untuk mengubah orientasi
  // newHeading += 10.0; // Menambahkan kompensasi 10 derajat
  if (newHeading < 0) {
    newHeading += 360.0;
  } else if (newHeading >= 360.0) {
    newHeading -= 360.0;
  }

  // Update filter
  headingFilter[filterIndex] = newHeading;
  filterIndex = (filterIndex + 1) % FILTER_SIZE;
  if (filterIndex == 0) {
    filterFilled = true;
  }

  // Calculate average heading

  float sumHeading = 0.0;
  int numSamples = filterFilled ? FILTER_SIZE : filterIndex;
  for (int i = 0; i < numSamples; i++) {
    sumHeading += headingFilter[i];
  }
  filteredHeading = sumHeading / numSamples;

  return filteredHeading;
}

 const char* compasDirection(){

  // Display cardinal direction
  if (filteredHeading >= 337.5 || filteredHeading < 22.5) {
    strcpy(newDirection, "N");
  } else if (filteredHeading >= 22.5 && filteredHeading < 67.5) {
    strcpy(newDirection, "NE");
  } else if (filteredHeading >= 67.5 && filteredHeading < 112.5) {
    strcpy(newDirection, "E");
  } else if (filteredHeading >= 112.5 && filteredHeading < 157.5) {
    strcpy(newDirection, "SE");
  } else if (filteredHeading >= 157.5 && filteredHeading < 202.5) {
    strcpy(newDirection, "S");
  } else if (filteredHeading >= 202.5 && filteredHeading < 247.5) {
    strcpy(newDirection, "SW");
  } else if (filteredHeading >= 247.5 && filteredHeading < 292.5) {
    strcpy(newDirection, "W");
  } else if (filteredHeading >= 292.5 && filteredHeading < 337.5) {
    strcpy(newDirection, "NW");
  }
  return newDirection;  
}

void drawCompassNeedle(float goal) {
  int centerX = 150;  // Tengah layar (disesuaikan jika perlu)
  int centerY = 130;  // Tengah layar (disesuaikan jika perlu)
  int length = 50;    // Panjang jarum

  // Konversi goal ke radian
  float angleRad = -goal * PI / 180.0; // Tidak perlu penyesuaian karena 0 derajat menunjuk ke N

  // Hitung koordinat ujung jarum
  int endX = centerX + length * sin(angleRad); // Menggunakan sin untuk x-axis karena orientasi layar landscape
  int endY = centerY - length * cos(angleRad); // Memflip sumbu y

  // Gambar jarum kompas
  lineCompass(centerX, centerY, endX, endY, TFT_BLACK);
}

void lineCompass(int x0, int y0, int x1, int y1, uint16_t color) {
  // Implementasikan fungsi menggambar garis sesuai dengan library yang digunakan
  tft.drawLine(x0, y0, x1, y1, color);
}

//======================================================================================
//------------------------------------End IMU-------------------------------------------
//======================================================================================

//======================================================================================
//--------------------------------------MIC---------------------------------------------
//======================================================================================
void i2s_install() {
  const i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_PDM),
    .sample_rate = 16000,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = bufferLen,
    .use_apll = false
  };

  i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
}

void i2s_setpin() { 
  const i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_PIN_NO_CHANGE,
    .ws_io_num = 32,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = 33
  };

  i2s_set_pin(I2S_PORT, &pin_config);
}

int countPeaks(const std::vector<int16_t>& data) {
  int peaks = 0;
  int16_t peakThreshold = 1000; // Threshold untuk menghitung peak yang signifikan

  for (size_t i = 1; i < data.size() - 1; ++i) {
    if (data[i] > data[i - 1] && data[i] > data[i + 1] && data[i] > peakThreshold) {
      peaks++;
    }
  }
  return peaks;
}

void analyzeWave() {
  unsigned long duration = endTime - playTime;
  int peakCount = countPeaks(waveData);

  Serial.println("Wave data collected:");
  for (size_t i = 0; i < waveData.size(); ++i) {
    Serial.println(waveData[i]);
  }

  Serial.print("Duration: ");
  Serial.println(duration);

  Serial.print("Peak count: ");
  Serial.println(peakCount);

  // Ubah logika untuk mendeteksi whistle dan clap
  if (duration > minWhistleDuration && peakCount >= minPeaksForWhistle) {
    whistleDetected = true;
  } else {
    clapDetected = true;
  }

  waveData.clear();
}


void micSetup(){
  i2s_install();
  i2s_setpin();
  i2s_start(I2S_PORT);
}
float readMic(){
  int rangelimit = 50;
  Serial.print(rangelimit * -1);
  Serial.print(" ");
  Serial.print(rangelimit);
  Serial.print(" ");

  // Get I2S data and place in data buffer
  size_t bytesIn = 0;
  esp_err_t result = i2s_read(I2S_PORT, &sBuffer, bufferLen, &bytesIn, portMAX_DELAY);

  if (result == ESP_OK)
  {
  // Read I2S data buffer
  int16_t samples_read = bytesIn / 8;
  if (samples_read > 0) {

  for (int16_t i = 0; i < samples_read; ++i) {
  mean += (sBuffer[i]);
  }

  // Average the data reading
  mean /= samples_read;
  }
  }
  return mean;
}

void readClapOrWhistle() {
  
  if (millis() - milTime < debounceDelay) {
    return; // Skip processing during debounce period
  }

  esp_err_t result = i2s_read(I2S_PORT, &i2s_read_buffer, bufferLen * sizeof(int32_t), &bytesIn, portMAX_DELAY);
  if (result == ESP_OK && bytesIn > 0) {
    int16_t samples_read = bytesIn / sizeof(int32_t);
    if (samples_read > 0) {
      for (int16_t i = 0; i < samples_read; ++i) {
        int16_t sample = abs((int16_t)(i2s_read_buffer[i] >> 16));

        if (!collectingWave) {
          if (sample > thresholdHigh) {
            collectingWave = true;
            tempWaveBuffer.clear();
            tempWaveBuffer.push_back(sample);
            playTime = millis();
            lastBelowThresholdTime = millis();
          }
        } else {
          tempWaveBuffer.push_back(sample);
          if (sample < thresholdLow) {
            if (millis() - lastBelowThresholdTime > thresholdDelay) {
              collectingWave = false;
              endTime = millis();
              waveData.insert(waveData.end(), tempWaveBuffer.begin(), tempWaveBuffer.end());
              analyzeWave();
              tempWaveBuffer.clear();
            }
          } else {
            lastBelowThresholdTime = millis();
          }
        }
      }
    }
  } else {
    Serial.printf("I2S read failed: %d\n", result);
  }
}

//======================================================================================
//------------------------------------End MIC-------------------------------------------
//======================================================================================
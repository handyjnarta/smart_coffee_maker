#ifndef PANDA_H
#define PANDA_H

#include <Arduino.h>

// Deklarasi array gambar (panda)
extern const unsigned char panda[];
extern const uint32_t panda_size;

#endif // PANDA_H

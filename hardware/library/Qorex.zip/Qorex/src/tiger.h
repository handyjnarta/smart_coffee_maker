// horse_data.h
#ifndef TIGER_H
#define TIGER_H

extern unsigned char tiger[];

#endif // TIGER_H

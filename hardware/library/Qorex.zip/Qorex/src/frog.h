// horse_data.h
#ifndef FROG_H
#define FROG_H

extern unsigned char frog[];

#endif // FROG_H

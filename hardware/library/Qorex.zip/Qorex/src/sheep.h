// horse_data.h
#ifndef SHEEP_H
#define SHEEP_H

extern unsigned char sheep[];

#endif // SHEEP_H

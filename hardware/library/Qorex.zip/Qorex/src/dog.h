// horse_data.h
#ifndef DOG_H
#define DOG_H

extern unsigned char dog[];

#endif // DOG_H

// horse_data.h
#ifndef ELEPHANT_H
#define ELEPHANT_H

extern unsigned char elephant[];

#endif // ELEPHANT_H

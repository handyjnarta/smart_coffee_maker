# ICM-20948
ICM-20948 port of the MPU-9250 Kris Winer Arduino library.

DP Eng's ICM-20948 Breakout Board is specifically developed for this library with 3 - 5V input including I2C & SPI voltage translation/level shifting and 10k Ohm pull-ups, you can purchase it on eBay or Amazon here:

<s>DP Eng ICM-20948 Breakout Board eBay Link with tracked international shipping</s> Sold out!

<s>DP Eng ICM-20948 Breakout Board available @ Amazon.co.uk</s> Sold out!

<img src="https://i.ebayimg.com/images/g/rYYAAOSwbURckVpf/s-l1600.jpg" />
The DP Eng ICM-20948 Breakout Board
